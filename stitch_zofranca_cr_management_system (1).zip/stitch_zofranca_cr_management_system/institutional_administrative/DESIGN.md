---
name: Institutional Administrative
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#43474f'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737780'
  outline-variant: '#c3c6d1'
  surface-tint: '#3a5f94'
  primary: '#001e40'
  on-primary: '#ffffff'
  primary-container: '#003366'
  on-primary-container: '#799dd6'
  inverse-primary: '#a7c8ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#002133'
  on-tertiary: '#ffffff'
  tertiary-container: '#003751'
  on-tertiary-container: '#0fa5e9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a7c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#1f477b'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 32px
  gutter: 24px
  section-gap: 48px
  stack-sm: 8px
  stack-md: 16px
---

## Brand & Style

The design system for this administrative platform is rooted in the concepts of **Authority, Efficiency, and Transparency**. Designed for the management of Free Trade Zones in Costa Rica, the visual language avoids decorative flourishes in favor of a **Corporate Modern** aesthetic. 

The system prioritizes high information density without sacrificing clarity, utilizing a structured grid and a disciplined color palette to evoke a sense of stability and government-grade reliability. The interface feels established and secure, designed to support long-duration administrative tasks with minimal cognitive load.

## Colors

The palette is anchored by **Deep Institutional Blue**, used for primary actions and structural navigation to reinforce authority. **Professional Slate** serves as the secondary color, providing a neutral balance for secondary UI elements.

- **Status Colors:** To ensure accessibility, status indicators (Recommended, Review, Rejected) utilize high-contrast shades combined with secondary visual cues like icons or patterns.
- **Surface Strategy:** The background uses a tiered approach of white and very light gray to separate global navigation from the primary workspace.
- **Interaction States:** Hover and active states are derived from a 10% brightness shift of the primary and secondary tokens.

## Typography

The design system utilizes **Inter** exclusively for its exceptional legibility in data-heavy environments. 

- **Scale:** A modular scale ensures a clear hierarchy between administrative headers and dense tabular data.
- **Readability:** Line heights are intentionally generous (1.5–1.6 for body text) to assist in scanning long-form documents and compliance records.
- **Labels:** Small labels and data headers use a slightly increased font weight and subtle letter spacing to distinguish them from editable content.

## Layout & Spacing

The layout utilizes a **Fixed Grid** model for desktop administrative dashboards to ensure predictable data visualization.

- **Sidebar:** A fixed 280px sidebar contains the primary navigation.
- **Main Canvas:** Content resides in a centered container with a maximum width of 1440px, utilizing a 12-column grid.
- **Spacing Rhythm:** Based on a 4px baseline. Most components use 16px (stack-md) for internal padding to maintain a clean, breathable interface.
- **Responsive Behavior:** On tablet, the sidebar collapses into a rail or hamburger menu; on mobile, grids reflow into a single column with a reduced container padding of 16px.

## Elevation & Depth

This design system uses **Tonal Layers** combined with **Ambient Shadows** to define hierarchy.

- **Level 0 (Flat):** Used for the main background and low-priority decorative containers.
- **Level 1 (Surface):** White cards for primary content, using a 1px border in a light gray (#E2E8F0) and no shadow.
- **Level 2 (Elevated):** Interactive cards or hovered items, utilizing a soft, diffused shadow (0px 4px 6px -1px rgba(0, 0, 0, 0.1)).
- **Level 3 (Overlay):** Modals and dropdowns, using a deeper shadow (0px 10px 15px -3px rgba(0, 0, 0, 0.1)) and a background backdrop blur of 4px to maintain focus.

## Shapes

The shape language is conservative and professional. The **Soft (0.25rem)** roundedness setting is the standard for most UI elements.

- **Inputs & Buttons:** 4px radius (rounded-sm) to maintain a crisp, structured appearance.
- **Cards & Modals:** 8px radius (rounded-lg) for a slightly softer, modern container feel.
- **Data Visuals:** Charts and status badges use the same 4px radius to ensure a cohesive geometric profile across all data points.

## Components

- **Buttons:** Primary buttons are solid Deep Institutional Blue with white text. Secondary buttons use a slate outline. All buttons use 8px 16px padding as a minimum.
- **Navigation Sidebar:** Uses a dark theme (Deep Blue background) to separate navigation from the white workspace. Active states are indicated by a high-contrast accent bar on the left edge.
- **Form Fields:** Inputs feature a 1px border. Focus state is a 2px offset ring in Institutional Blue. Errors must display a red icon and descriptive text below the field, not just a color change.
- **Status Chips:** Small, low-contrast background fills with high-contrast text and a leading icon (e.g., Check for Recommended, Alert for Review, X for Rejected).
- **Data Tables:** Highly structured with subtle horizontal separators. Header rows use a light gray fill and bold labels for clear categorization of administrative columns.
- **Alerts:** Inline alerts for "Cumplimiento" (Compliance) updates use a vertical color bar on the left side to signal priority without overwhelming the user.